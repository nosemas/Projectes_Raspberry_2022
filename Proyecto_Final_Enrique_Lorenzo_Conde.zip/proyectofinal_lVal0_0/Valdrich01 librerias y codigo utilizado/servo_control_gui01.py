'''CONTROLSERVO Y VISUALIZADO DATOS SENSOR GUI'''

from gpiozero import Servo, DistanceSensor
from guizero import App, Box, Text, PushButton, Slider
from time import sleep

servo = Servo(17, 0, 0.0005, 0.0025)
sensor = DistanceSensor(echo=18, trigger=27)

def ServoPosition(slider_value):
    servo.value = int(slider_value) / 90

def my_user_task():
    print("Distance: {0:.2f}cm".format(sensor.distance * 100))
    reading_text.value = "{0:.2f}".format(sensor.distance * 100)

app = App(title="Servo GUI", width=350, height=150, layout="auto")

instruction_text = Text(app, text="Drag slider below to control servo position.")
instruction_text.repeat(1000, my_user_task)
servo_position = Slider(app, command=ServoPosition, start=-90, end=90, width='fill')
distance_text = Text(app, text="Distance (cm):")
reading_text = Text(app, text="---")
designby_text = Text(app, text="Idris - Cytron Technologies", align='bottom')

app.display()


'''CONTROL SERVO SIMPLE CON 1 BOTON GUI'''

from tkinter import *
#Thinter in python 2
import RPi.GPIO as io
import time

io.setwarnings(False) 
io.setmode(io.BCM)

io.setup(18,io.OUT)
io.setup(13,io.OUT)
io.setup(12,io.OUT)
hombro=io.PWM(19,50)
codo=io.PWM(18,50)
tilt=io.PWM(13,50)
pan=io.PWM(12,50)

hombro.start(0)
codo.start(0)
tilt.start(0)
pan.start(0)

root = Tk()
Label(root, text="Angle codo").grid(row=0)
e1 = Entry(root)
e1.grid(row=0, column=1)

def cal():
    global dc
    deg1 =e1.get()
    deg = abs(float(deg1))
    dc = 0.056*deg + 2.5
    codo.ChangeDutyCycle(dc)
    print(deg, dc)
   
b1= Button(root, text = "Enter",bg="pink", command =cal)
b1.grid(row=2, column=1)
b3 = Button(root, text='Quit', bg= "cyan", command=root.quit)
b3.grid(row=2, column=3)
root.mainloop()
