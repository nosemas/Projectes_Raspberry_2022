from tkinter import *
import RPi.GPIO as GPIO
from time import sleep

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup([12,13,18,19],GPIO.OUT)

tilt=GPIO.PWM(12,100)
pan=GPIO.PWM(13,100)
codo=GPIO.PWM(18,100)
hombro=GPIO.PWM(19,100)

tilt.start(0)
pan.start(0)
codo.start(0)
hombro.start(0)

print ("Initialating Valdrich")
sleep(1)

root = Tk()
root.title('Servo Control lVal0_0 ')
root.geometry("900x500")



class lVal0_0:

    def __init__(self, main([Hombro, Codo, Pan, Tilt])):
		print("Frame and sliders on creation...Slides are being created!!! ")
        servosFrame = Frame(main)
		servosFrame.pack()
		self.exit = Button(main, text="exit", command=self.exit)
		self.exit.pack(paddy=5)
		
        self.Hombro = Scale(main, from_=1, to_=179,
              orient=HORIZONTAL, command=self.updateHombro)
        Hombro.grid(row=0)
        Hombro.pack(paddy=5)
		
	
        self.Codo = Scale(main, from_=1, to_=179,
              orient=HORIZONTAL, command=self.updateCodo)
        Codo.grid(row=1)
        Codo.pack(paddy=5)
		
		
        self.Tilt = Scale(main, from_=1, to_=179,
              orient=VERTICAL, command=self.updateTilt)
        Tilt.grid(row=4)
        Tilt.pack(paddy=5)
		
		
        self.Pan = Scale(main, from_=1, to_=179,
              orient=HORIZONTAL, command=self.updatePan)
        Pan.grid(row=3)
        pan.pack(paddy=5)
		
		
		
	def exit(self):
		print("U exit lVal0_0....")
		GPIO.cleanup()
		lVal0_0.quit()

    def updateHombro(self, Hombro):
		print("lVal0_0 is moooooving chab!!!! yeeeeaah!!!")
        duty = float(angle) / 18.0 + 2.5
        hombro.ChangeDutyCycle(duty)
        sleep(0.1)
        if(angle == angle):
            hombro.ChangeDutyCycle(0)
            sleep(0.2)
			duty = duty
			sleep(0.5)
			
	def updateCodo(self, Codo):
        duty = float(angle) / 18.0 + 2.5
        codo.ChangeDutyCycle(duty)
        sleep(0.1)
        if(angle == angle):
            codo.ChangeDutyCycle(0)
            sleep(0.2)
            duty = duty	
            sleep(0.5) 
	def updateTilt(self, Tilt):
        duty = float(angle) / 18.0 + 2.5
        tilt.ChangeDutyCycle(duty)
        sleep(0.1)
        if(angle == angle):
            tilt.ChangeDutyCycle(duty)
            sleep(0.1)
            duty = duty
			sleep(0.5)
			
	def update(self, Pan):
        duty = float(angle) / 18.0 + 2.5
        pan.ChangeDutyCycle(duty)
        sleep(0.1)
        if(angle==angle):
            pan.ChangeDutyCycle(duty)
            sleep(0.2)
            duty = duty
			sleep(0.5)



root.mainloop()