'''LittleValdrich0_0, interface slide & bottons'''

from tkinter import *
from tkinter import ttk
from tkinter.font import Font 
import RPi.GPIO as GPIO
from time import sleep


GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup([12,13,18,19],GPIO.OUT)

tilt=GPIO.PWM(12,50)
pan=GPIO.PWM(13,50)
codo=GPIO.PWM(18,50)
hombro=GPIO.PWM(19,50)

tilt.start(0)
pan.start(0)
codo.start(0)
hombro.start(0)

def show_values():
    print (pan.get(), tilt.get(), codo.get(), hombro.get())

def exitProgram():
    GPIO.cleanup()
    win.quit()  


def duty(win):
    pan = int(pan_scale.get())
    pan.value = pan.ChangeDutyCycle(2+(pan.value/18))
    sleep(0.3)
    pan.ChangeDutyCycle(0)
    
    tilt = int(tilt_scale.get())
    tilt.value = tilt.ChangeDutyCycle(2+(tilt.value/18))
    sleep(0.3)
    tilt.ChangeDutyCycle(0)
    
    codo = int(codo_scale.get())
    codo.value = pan.ChangeDutyCycle(2+(codo.value/18))
    sleep(0.3)
    codo.ChangeDutyCycle(0)
    
    hombro = int(hombro_scale.get())
    hombro.value = hombro.ChangeDutyCycle(2+(hombro.value/18))
    sleep(0.3)
    hombro.ChangeDutyCycle(0)



root = Tk()

my_font = Font(family = 'Times', size = 30, weight = 'bold', slant = 'roman', 
    underline = 1, overstrike = 0)

lVal0_0.title("lVal0_0.......SERVO CONTROL........")
lVal0_0.geometry('800x800')
lVal0_0.pac()

OFF  = Button(lVal0_0, text = "Exit", font = myFont, command = exitProgram, 
    height =2 , width = 6 )
OFF.pack(side = BOTTOM)

pan_scale= Scale(lVal0_0, from_=0, to=180, orient=HORIZONTAL, length=700, bg='blue', 
    command = duty)
pan_scale.place(x=50, y=220)

tilt_scale= Scale(lVal0_0, from_=0, to=180, length=700, bg='blue', command = duty)
tilt_scale.place(x=150, y=220)

codo_scale= Scale(lVal0_0, from_=0, to=180, orient=HORIZONTAL, length=700, bg='grey', 
    command = duty)
codo_scale.place(x=250, y=220) 

hombro_scale= Scale(lVal0_0, from_=0, to=180, orient=HORIZONTAL, length=700, bg='grey', 
    command = duty)
hombro_scale.place(x=350, y=220)


root.mainloop()

