from gpiozero import AngularServo
from guizero import App, ButtonGroup, Text

app=App(title="Servo_GUI", layout="grid")
'''s = AngularServo(17, min_angle=-90, max_angle=90)'''
codo = AngularServo(18, min_angle=-90, max_angle=90)
tilt = AngularServo(13, min_angle=-90, max_angle=90)
pan = AngularServo(12, min_angle=-90, max_angle=90)

def update_text():
    '''s.angle = int(choice.value)
    print("motor1: ", s.angle)'''
    codo.angle = int(choice1.value)
    print("motorcodo: ",codo.angle)
    tilt.angle = int(choice2.value)
    print("motortilt: ",tilt.angle)
    pan.angle = int(choice3.value)
    print("motorpan: ",pan.angle, "\n------------------------------------------------")

'''choice =ButtonGroup(app, options=["-90", "-45", "0", "45", "90"], selected="-90",command=update_text, grid=[1,2])'''
choice1 =ButtonGroup(app, options=["-90", "-45", "0", "45", "90"], selected="-90", command=update_text, grid=[2,2])
choice2 =ButtonGroup(app, options=["-90", "-45", "0", "45", "90"], selected="-90", command=update_text, grid=[3,2])
choice3 =ButtonGroup(app, options=["-90", "-45", "0", "45", "90"], selected="-90", command=update_text, grid=[4,2])

'''Text(app, "M1",grid=[1,1])'''
Text(app, "M2",grid=[2,1])
Text(app, "M3",grid=[3,1])
Text(app, "M4",grid=[4,1])
app.display()