
'''TESTSERVO CODO'''

import RPi.GPIO as IO
import time *

IO.setmode(IO.BCM)
IO.setup([18,13,12],IO.OUT)
codo=IO.PWM(18,50)
codo.start(0)

def testcodo():
	print (" Testing codo began.. ")
	duty=2
	sleep(1)
	while duyty <=12:
		codo.ChangeDutyCycle(duty)
		sleep(0.5)
		codo.ChangeDutyCycle(0)
		sleep(0.5)
		duty=duty +1
	print (" Codo llego al tope... ")
	
	if duty=12:
		codo.ChangeDutyCycle(duty)
		sleep(0.5)
		codo.ChangeDutyCycle(0)
		sleep(0.5)
		duty=duty -1
	print (" Codo llego al limite opuesto.. ")
	
def main():
    while 1:
        testcodo()

if __name__ == 'main()':
    main()

	
