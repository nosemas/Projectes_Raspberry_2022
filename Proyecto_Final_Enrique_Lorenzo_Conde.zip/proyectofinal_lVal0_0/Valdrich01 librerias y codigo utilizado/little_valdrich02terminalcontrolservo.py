'''PROYECTO FINAL CODIGO DE LITTLE VALDRICH, moviendo servos desde terminal'''

import RPi.GPIO as GPIO
from time import sleep 

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup([12,13,18,19],GPIO.OUT)
tilt=GPIO.PWM(12,50)
pan=GPIO.PWM(13,50)
codo=GPIO.PWM(18,50)
hombro=GPIO.PWM(19,50)

tilt.start(0)
pan.start(0)
codo.start(0)
hombro.start(0)

print ("Initialating Valdrich")
sleep(1)

try:
	while True:
        anglehombro=float(input('Enter hombro angle: '))
        anglecodo=float(input('Enter codo angle: '))
        angletilt=float(input('Enter tilt angle: '))
        anglepan=float(input('Enter pan angle: '))
        sleep(0.5)
        tilt.ChangeDutyCycle(2+(angletilt/18))
        pan.ChangeDutyCycle(2+(anglepan/18))
        codo.ChangeDutyCycle(2+(anglecodo/18))
        hombro.ChangeDutyCycle(2+(anglehombro/18))
        sleep(0.3)
        tilt.ChangeDutyCycle(0)
        pan.ChangeDutyCycle(0)
        codo.ChangeDutyCycle(0)
        hombro.ChangeDutyCycle(0)
        
        
finally:
    tilt.stop()
    pan.stop()
    codo.stop()
    hombro.stop()
    GPIO.Cleanup()
    print ("Little Valdrich,say's cherryooO_O but")
        
        
        
        
