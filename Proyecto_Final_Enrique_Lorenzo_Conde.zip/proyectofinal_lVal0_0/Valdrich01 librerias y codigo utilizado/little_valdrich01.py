'''EJEMPLO PAN TILT 180º y rotaciones 90º, continuas'''
import RPi.GPIO  as GPIO
from time import sleep



def setup():
	GPIO.setmode(GPIO.BCM)
	GPIO.setwarnings(False)
	GPIO.setup([12,13,18],GPIO.OUT)

	tilt=GPIO.PWM(12,50)
	pan=GPIO.PWM(13,50)
	codo=GPIO.PWM(18,50)

	tilt.start(0)
	pan.start(0)
	codo.start(0)
	print("Initialating Valdrich")
	sleep(1)



def pan():
    duty=2
    print ("R otando 180º en pasos de 10º ") 	
    while(duty <= 12):  
        try:
	   pan.ChangeDutyCycle (duty)
           sleep(0.3)
           pan.ChangeDutyCycle(0)
           sleep(2)
           duty= duty+1
	    
        except KeyboardInterrupt:
            pan.stop()
            GPIO.cleanup()
            print ("Saliendo de movimiento pan")
            sleep(3)


def codo90 ():
	print ("Codo a 90º")
	pan.ChangeDutyCycle(7)
	sleep(0.3)
	pan.ChangeDutyCycle(0)
	sleep(1.5)
	codo.stop()
	GPIO.cleanup()
	print ("codo en 90º")

def codo0 ():
	print ("Codo a 0º")
	pan.ChangeDutyCycle(2)
	sleep(0.3)
	pan.ChangeDutyCycle(0)
	sleep(1.5)
	GPIO.cleanup()
	codo.stop()
	print ("Codo en 0º")

def main ():
    setup()
    while 1:
       pan()

if __name__== '__main__' :

 main()


