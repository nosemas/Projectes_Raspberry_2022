
from tkinter import *
from tkinter import ttk
from tkinter.font import Font
import RPi.GPIO as GPIO
import time
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup([19,18,13,12], GPIO.OUT)

hombro = GPIO.PWM(19, 100)
codo = GPIO.PWM(18, 100)
pan = GPIO.PWM(13, 100)
tilt = GPIO.PWM(12, 100)

hombro.start(0)
codo.start(0)
pan.start(0)
tilt.start(0)

root = Tk()

class App:

    def __init__(self, master):
        frame = Frame(master)
        frame.pack()
        my_font = Font(family = 'Times', size = 14, weight = 'bold',
		slant = 'roman', underline = 1, overstrike = 0)

        Exit = Button(frame, text = "Exit", font = my_font,
             activeforeground ='green', command = self.exit,
             height = 1 , width = 1)
        Exit.pack(side = BOTTOM)

        Hombro = Scale(frame, from_=0, to=380,
              orient=HORIZONTAL, command=self.updateH)
        Hombro.pack()

        Codo = Scale(frame, from_=0, to=180,
              orient=HORIZONTAL, command=self.updateC)
        Codo.pack()

        Pan = Scale(frame, from_=0, to=180,
              orient=HORIZONTAL, command=self.updateP)
        Pan.pack()

        Tilt  = Scale(frame, from_=0, to=180,
              orient=HORIZONTAL, command=self.updateT)
        Tilt.pack()

    def exit(self,App):
        GPIO.cleanup()
        App.quit()

    def updateH(self, angle):
        duty = float(angle) / 10.0 + 2.5
        hombro.ChangeDutyCycle(duty)
        time.sleep(0.3)
        hombro.ChangeDutyCycle(0)
        time.sleep(0.3)
        hombro.ChangeDutyCycle(duty)
    def updateC(self, angle):
        duty = float(angle) / 10.0 + 2.5
        codo.ChangeDutyCycle(duty)
        time.sleep(0.3)
        codo.ChangeDutyCycle(duty)
        time.sleep(0.3)

    def updateP(self, angle):
        duty = float(angle) / 10.0 + 2.5
        pan.ChangeDutyCycle(duty)
        time.sleep(0.3)
        pan.ChangeDutyCycle(0)
        time.sleep(0.3)

    def updateT(self, angle):
        duty = float(angle) / 10.0 + 2.5
        tilt.ChangeDutyCycle(duty)
        time.sleep(0.3)
        tilt.ChangeDutyCycle(0)
        time.sleep(0.3)




root.wm_title('Servo Control')
app = App(root)
root.geometry("200x50+0+0")
root.resizable(True, True)
root.mainloop()
