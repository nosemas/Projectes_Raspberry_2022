
import tkinter 
import RPi.GPIO as io
import time

io.setwarnings(False) 
io.setmode(io.BCM)

io.setup(18,io.OUT)
io.setup(13,io.OUT)
io.setup(12,io.OUT)

codo=io.PWM(18,50)
tilt=io.PWM(13,50)
pan=io.PWM(12,50)

codo.start(2.5)
tilt.start(2.5)
pan.start(2.5)

root = Tk()
Label(root, text="Angle codo").grid(row=0)
e1 = Entry(root)
e1.grid(row=0, column=1)

def cal():
    global dc
    deg1 =e1.get()
    deg = abs(float(deg1))
    dc = 0.056*deg + 2.5
    codo.ChangeDutyCycle(dc)
    print(deg, dc)
   
b1= Button(root, text = "Enter",bg="pink", command =cal)
b1.grid(row=2, column=1)
b3 = Button(root, text='Quit', bg= "cyan", command=root.quit)
b3.grid(row=2, column=3)
root.mainloop()
