'''lVal0_0 beta de brazo/vision de lVal0_0'''



from tkinter import *
from tkinter.tk import ttk
from tkinter.font import Font 
import RPi.GPIO as GPIO
from time import sleep 

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup([12,13,18,19],GPIO.OUT)

tilt=GPIO.PWM(12,50)
pan=GPIO.PWM(13,50)
codo=GPIO.PWM(18,50)
hombro=GPIO.PWM(19,50)

tilt.start(0)
pan.start(0)
codo.start(0)
hombro.start(0)

print ("Initialating lVal0_0.....hold 2 seconds")
sleep(1)


	
def pan(scale_value):
    pan = input(pan_scale.get())
    pan.scale = pan.ChangeDutyCycle(2+(scale_value/18))
    sleep(0.3)
    pan.ChangeDutyCycle(0)
	
def tilt(scale_value):
    tilt = input(tilt_scale.get())
    tilt.value = tilt.ChangeDutyCycle(2+(scale_value/18))
    sleep(0.3)
    tilt.ChangeDutyCycle(0)
    
def codo(scale_value):
    codo = input(codo_scale.get())
    codo.value = pan.ChangeDutyCycle(2+(codo.value/18))
    sleep(0.3)
    codo.ChangeDutyCycle(0)
    
def hombro(scale_value):
    hombro = input(hombro_scale.get())
    hombro.value = hombro.ChangeDutyCycle(2+(hombro.value/18))
    sleep(0.3)
    hombro.ChangeDutyCycle(0)
	
def exitProgram():
    GPIO.cleanup()
    lVal0_0.quit()
	
	
lVal0_0 = Tk()

lVal0_0.title('Seting lVal0_0 in position ')

my_font = Font(family = 'Times', size = 13, weight = 'bold', slant = 'roman',
    underline = 0, overstrike = 0)

lVal0_0.title("lVal0_0.......SERVO CONTROL........")
lVal0_0.geometry('300x200')


OFF  = Button(lVal0_0, text = "Exit", font = my_font, activeforeground ='green',  command = exitProgram,
	     height = 1 , width = 1)
OFF.pack(side = TOP)

pan_scale= Scale(lVal0_0, from_=1, to_=179, orient=HORIZONTAL, length=100, bg='blue',
           command = pan)
pan_scale.place(x=5,y=40)

tilt_scale= Scale(lVal0_0, from_=1, to_=179, length=100, bg='blue', command = tilt )
tilt_scale.place(x=5, y=85)

codo_scale= Scale(lVal0_0, from_=1, to_=179, orient=HORIZONTAL, length=100, bg='grey',
            command = codo)
codo_scale.place(x=75, y=85)

hombro_scale= Scale(lVal0_0, from_=1, to=179, orient=HORIZONTAL, length=100, bg='grey', 
	          command = hombro)
hombro_scale.place(x=75, y=135)


lVal0_0.mainloop()

