from tkinter import *
import RPi.GPIO as GPIO
from time import sleep

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup([12,13,18,19],GPIO.OUT)

tilt=GPIO.PWM(12,100)
pan=GPIO.PWM(13,100)
codo=GPIO.PWM(18,100)
hombro=GPIO.PWM(19,100)

tilt.start(0)
pan.start(0)
codo.start(0)
hombro.start(0)

print ("Initialating Valdrich")
sleep(1)



class lVal0_0:


    def __init__(self, Hombro):
        Hombro = Frame(Hombro)
        Hombro = Scale(Hombro, from_=1, to=179,
              orient=HORIZONTAL, command=self.update)
        Hombro.grid(row = 0)
        Hombro.pack()

    def update(self, Hombro):
        duty = float(angle) / 18.0 + 2.5
        hombro.ChangeDutyCycle(duty)
        sleep(0.1)
        if(angle == angle):
            hombro.ChangeDutyCycle(0)
            sleep(0.2)
            duty = duty

    def __init__(self, Codo):
        Codo = Frame(Codo)
        Codo.pack()
        Codo = Scale(Codo, from_=1, to=179,
              orient=HORIZONTAL, command=self.update)
        Codo.grid(row = 1)
        Codo.pack()

    def update(self, Codo):
        duty = float(angle) / 18.0 + 2.5
        codo.ChangeDutyCycle(duty)
        sleep(0.1)
        if(angle == angle):
            codo.ChangeDutyCycle(0)
            sleep(0.2)
            duty = duty


    def __init__(self, Tilt):
        self.Tilt = Frame(Tilt)
        Tilt = Scale(Tilt, from_=1, to=179,
              orient=VERTICAL, command=self.update)
        scale.grid(row=4)
        Tilt.pack()

    def update(self, Tilt):
        duty = float(angle) / 18.0 + 2.5
        tilt.ChangeDutyCycle(duty)
        sleep(0.1)
        if(angle == angle):
            tilt.ChangeDutyCycle(0)
            sleep(0.1)
            duty = duty


    def __init__(self, Pan):
        self.Pan = Frame(Pan)
        Pan = Scale(Pan, from_=1, to=179,
              orient=HORIZONTAL, command=self.update)
        Pan.grid(row=3)
        pan.pack()

    def update(self, Pan):
        duty = float(angle) / 18.0 + 2.5
        pan.ChangeDutyCycle(duty)
        sleep(0.1)
        if(angle==angle):
            pan.ChangeDutyCycle(0)
            sleep(0.2)
            duty = duty



root = Tk()
root.wm_title('Servo Control')
app = App()
root.geometry("900x500")
root.mainloop()

