'''TESTSERVO CODO'''

import RPi.GPIO as IO
import time 

IO.setwarnings(False)
IO.setmode(IO.BCM)
IO.setup(18,IO.OUT)
codo=IO.PWM(18,50)
codo.start(0)

def testcodo():
	print (" Testing codo began.. ")
	duty=2
	time.sleep(1)
	while duyty <=12:
		codo.ChangeDutyCycle(duty)
		time.sleep(0.5)
		codo.ChangeDutyCycle(0)
		time.sleep(0.5)
		duty=duty +1
	print (" Codo llego al tope... ")
	
	
	
def main():
    while 1:
        testcodo()
          
if __name__ == 'main()':
    main()

