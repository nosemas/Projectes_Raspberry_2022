'''OTRO EJEMPLO SERVO CON TKINTER slider FUNCIONA'''


from Tkinter import *
import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)
GPIO.setup(18, GPIO.OUT)
pwm = GPIO.PWM(18, 100)
pwm.start(5)

class App:

    def __init__(self, master):
        frame = Frame(master)
        frame.pack()
        scale = Scale(frame, from_=0, to=180,
              orient=HORIZONTAL, command=self.update)
        scale.grid(row=0)


    def update(self, angle):
        duty = float(angle) / 10.0 + 2.5
        pwm.ChangeDutyCycle(duty)

root = Tk()
root.wm_title('Servo Control')
app = App(root)
root.geometry("200x50+0+0")
root.mainloop()


'''CODOGO TROCEADO PARA PROVAR'''

from Tkinter import *
import RPi.GPIO as GPIO
from time import  sleep 



GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup([12,13,18,19],GPIO.OUT)

tilt.start(0)
pan.start(0)
codo.start(0)
hombro.start(0)

tilt=GPIO.PWM(12,100)
pan=GPIO.PWM(13,100)
codo=GPIO.PWM(18,100)
hombro=GPIO.PWM(19,100)

class App:

    def hombro(self, master):
        frame = Frame(master)
        frame.pack()
        scale = Scale(frame, from_=1, to=179,
              orient=HORIZONTAL, command=self.update)
        scale.grid(row=0)


    def update(self, angle):
        duty = float(angle) / 18.0 + 2.5
        hombro.ChangeDutyCycle(duty)
		time.sleep(0.3)
        hombro.ChangeDutyCycle(0)

root = Tk()
root.wm_title('Servo Control')
app = App(root)
root.geometry("200x50+0+0")
root.mainloop()